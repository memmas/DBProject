package team32;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Enumeration;
import java.util.Formatter;
import java.util.Hashtable;
import java.util.stream.Stream;

public class DBApp implements java.io.Serializable{
	
	
	public final static ArrayList<Table> Tables = new ArrayList<Table>();
	static String filename = "/home/memmas/WorkPlace2/DB.zip_expanded/team32/Data/metadata.csv";
	static boolean written= false;


	public void deleteFromTable(String strTableName,Hashtable<String,Object> htblColNameValue) throws Exception{
		for (int i=0; i<Tables.size();i++){
			if(Tables.get(i).getName().equals(strTableName)){
				for(int j=0; j<Tables.get(i).getTuples().size(); j++){
					
					if(Tables.get(i).getTuples().get(j).equals(htblColNameValue)){
						Tables.get(i).getTuples().remove(j);
					}
				}
				for (int k=0; k<Tables.get(i).getPages().size();k++){
					for(int z=0;z<Tables.get(i).getPages().get(k).getTuples().size();z++){
						if(Tables.get(i).getPages().get(k).getTuples().get(z).equals(htblColNameValue)){
							Tables.get(i).getPages().get(k).getTuples().remove(htblColNameValue);
							Tables.get(i).getPages().get(k).printToFile();
						}
					}
				}
			}
		}
	}
	
	public void createTable(String strTableName,String strClusteringKeyColumn,Hashtable<String,String> htblColNameType ) 
			throws IOException,DBAppException
	
			{
		//separating the hashtable
		 ArrayList<String> keys = new ArrayList<>();
		    ArrayList<String> values = new ArrayList<>();
		    Enumeration e = htblColNameType.keys();
		    while(e.hasMoreElements()){
		    	String key = (String) e.nextElement();
		    	keys.add(key);
		    }
		    for(String key: keys){
		    	values.add(htblColNameType.get(key));
		    }
		//creating the table
		Table t = new Table(strTableName,strClusteringKeyColumn,htblColNameType);
		//adding it to the list of tables
		Tables.add(t);
		
		//creating the CSV file
		createWriteCSV(strTableName,strClusteringKeyColumn,keys,values);	
		
		
	}
	
	public void insertIntoTable(String strTableName,
			Hashtable<String,Object> htblColNameValue) throws DBAppException, ClassNotFoundException
			{
		
		for(Table t : Tables){
			if(t.getName().equals(strTableName)){
				if(checktuple(htblColNameValue, t.getHtblColNameType())){
				htblColNameValue.put("TouchDate",Calendar.getInstance() );
				t.addToTuples(htblColNameValue);
				System.out.println("Insert successful");
				break;}
				else{
					System.out.println("invalid input to required table");
				}
			}		
		}
	}
	
	
	public static void createWriteCSV(String tableName,String ID, ArrayList<String> keys, ArrayList<String> values) throws IOException{
		if(!written){
			Formatter f= new Formatter (filename);
		//File cf= new File(filename);
			}
		FileInputStream f = new FileInputStream(filename);
		   FileWriter file = new FileWriter(filename,true);
		    
		  //  "Table Name, Column Name, Column Type, Key, Indexed"
		   if(!written){
			   
		    file.append("Table Name");
		    file.append(',');
		    file.append("Column Name");
		    file.append(',');
		    file.append("Column Type");
		    file.append(',');
		    file.append("Key");
		    file.append(',');
		    file.append("Indexed");
		    file.append("\n");
		    written= true;}
	    
	    for(int i = 0; i < keys.size();i++){
	    	file.append(tableName);
	    	file.append(',');
	    	file.append(keys.get(i));
	    	file.append(',');
	    	file.append(values.get(i));
	    	file.append(',');
	    	if(keys.get(i).equals(ID)) file.append("True");
	    	else file.append("False");
	    	file.append(',');
	    	file.append("False");
	    	file.append("\n");
	    }
	    file.flush();
	    file.close();
	    
		
		
	}
	
	
	
	
	public void updateTable(String strTableName,Object strKey,Hashtable<String,Object> htblColNameValue
			)throws DBAppException{
		
		for(int i = 0; i < this.Tables.size();i++) {
			if(Tables.get(i).getName().equals(strTableName)) {
				for(int j = 0 ; j < Tables.get(i).getTuples().size();j++) {
					if((Tables.get(i).getTuples().get(j).get(Tables.get(i).getStrCusteringKeyColumn())).equals(strKey))    {	     			
						Tables.get(i).getTuples().remove(j);
						Tables.get(i).addToTuples(htblColNameValue);
						
					}
				}
			}
		}
		
		
		
	}
	
	public  static void  RetriveDataBaseHelper(String path) throws Exception {
		FileInputStream fin = new FileInputStream(path);
		ObjectInputStream in = new ObjectInputStream(fin);
		Page p =  (Page)in.readObject();
		Boolean flag = true;
		System.out.println(p.getName());
		for(int i = 0 ; i < Tables.size();i ++) {
			if(p.getName() == Tables.get(i).getName())
			{
				for(int j = 0 ;  j < p.getTuples().size();j ++) {
					Tables.get(i).addToTuples(p.getTuples().get(j));
	
				}
				flag = !flag;
			}
		}
		if(flag) {
			System.out.println("no");
			Tables.add(new Table(p.getName(), p.getStrCusteringKeyColumn(),p.getHtblColNameType()));
			for(int j = 0 ;  j < p.getTuples().size();j ++) {
				Tables.get(Tables.size()-1).addToTuples(p.getTuples().get(j));
			}
		}
		in.close();
		fin.close();
	}
	
	
	public  static void  RetriveDataBase() throws Exception{

		Path[] PathArray;
		
			
			try (Stream<Path> paths = Files.walk(Paths.get("/home/memmas/WorkPlace2/DB.zip_expanded/team32/Data/DataBase"))) {
				PathArray = paths.toArray(size -> new Path[size]);
			} 
			System.out.println(PathArray.length);
			for(int i1 = 1; i1 < PathArray.length;i1++) {
				try {
					RetriveDataBaseHelper(PathArray[i1].toString());
				} catch (Exception e) {					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	}
	
	public boolean checktuple (Hashtable <String, Object> tuple, Hashtable <String,String> table) throws ClassNotFoundException{
		ArrayList<String> keysT = new ArrayList<>();
	    ArrayList<Object> valuesT = new ArrayList<>();
	    ArrayList<String> keysTable = new ArrayList<>();
	    ArrayList<Object> valuesTable = new ArrayList<>();
	    Enumeration e = tuple.keys();
	    while(e.hasMoreElements()){
	    	String key = (String) e.nextElement();
	    	keysT.add(key);
	    }
	    for(String key: keysT){
	    	valuesT.add(tuple.get(key));
	    }
	    Enumeration e2 = table.keys();
	    while(e2.hasMoreElements()){
	    	String key1 = (String) e2.nextElement();
	    	keysTable.add(key1);
	    
	    }
	    for(String key: keysTable){
	    	valuesTable.add(table.get(key));
	    }
	    for(int i=0; i<keysTable.size(); i++){
	    if(!(keysTable.get(i).equals(keysT.get(i)))){
	    return false;	
	    }
	    }
	    for (int i=0; i<valuesTable.size();i++){
	    		String val= (String)valuesTable.get(i);
				Class cl = Class.forName(val);
				Object o= valuesT.get(i);
				if(!(cl.isInstance(o))){
					return false;
				}
	    }
	   
	    
	    
	    return true;
	}
	
	public static void main(String[] args) throws Exception {

		DBApp a = new DBApp();
		
		Hashtable<String, String> ha = new Hashtable<String, String>();
		ha.put("id", "java.lang.Integer");
		ha.put("name", "java.lang.String");
		//a.createTable("Students", "id", ha);
		
		Hashtable<String, Object> h = new Hashtable<String, Object>();
		h.put("id", 50);
		h.put("name", "Sam");
	    a.insertIntoTable("Students", h);
	
	    Hashtable<String, Object> h1 = new Hashtable<String, Object>();
	    h1.put("id", 3);
	    h1.put("name", "Ali");
        a.insertIntoTable("Students", h1);
        
        
      h1 = new Hashtable<String, Object>();
	    h1.put("id", 4);
	    h1.put("name", "Nariman");
      a.insertIntoTable("Students", h1);
      
      h1 = new Hashtable<String, Object>();
	    h1.put("id", 6);
	    h1.put("name", "Nadine");
      a.insertIntoTable("Students", h1);
      
      h1 = new Hashtable<String, Object>();
	    h1.put("id", 8);
	    h1.put("name", "Mai");
      a.insertIntoTable("Students", h1);
  
      h1 = new Hashtable<String, Object>();
	    h1.put("id", 5);
	    h1.put("name", "Mohamed");
      a.insertIntoTable("Students", h1);
      
      h1 = new Hashtable<String, Object>();
	    h1.put("id", 16);
	    h1.put("name", "Marwa");
      a.insertIntoTable("Students", h1);
      
	    a.deleteFromTable("Students", h1);

	    
	    DBApp kl = new DBApp();
	    kl.RetriveDataBase();
	    
      
	    System.out.println(kl.Tables.size());
	    for(int i = 0; i < kl.Tables.size();i++) {
			if(kl.Tables.get(i).getName().equals("Students")) {
				for(int j = 0 ; j < kl.Tables.get(i).getTuples().size();j++) {
					
					if((kl.Tables.get(i).getTuples().get(j).get(kl.Tables.get(i).getStrCusteringKeyColumn())).equals(16))    {	     			
						System.out.println("opps");
					}
					else {
					//	System.out.println("yay!!!");

					}
				}
			}
		}

      
		
      
		
	}
	
	
	
}





















