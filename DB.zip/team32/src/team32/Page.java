package team32;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Hashtable;


public class Page implements java.io.Serializable{

	private String name;
	private Hashtable<String,String> htblColNameType;
	private ArrayList<Hashtable<String, Object>>Tuples;
	private final int max =200;
	private ArrayList<Path> paths = new ArrayList<Path>();
	final static String Folder = "/home/memmas/WorkPlace2/DB.zip_expanded/team32/Data/DataBase";
	private  String FileName;
	private String strCusteringKeyColumn;

	
	public Page(String name,Hashtable<String,String> htblColNameType,String Filname,String strCusteringKeyColumn){
		this.FileName =Filname;
		this.name =name;
		this.strCusteringKeyColumn = strCusteringKeyColumn;
		this.setHtblColNameType(htblColNameType);
		Tuples = new ArrayList<Hashtable<String,Object>>();
	}


	public ArrayList<Path> getPaths() {
		return paths;
	}


	public void setPaths(ArrayList<Path> paths) {
		this.paths = paths;
	}


	public String getStrCusteringKeyColumn() {
		return strCusteringKeyColumn;
	}


	public void setStrCusteringKeyColumn(String strCusteringKeyColumn) {
		this.strCusteringKeyColumn = strCusteringKeyColumn;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public ArrayList<Hashtable<String, Object>> getTuples() {
		return Tuples;
	}


	public void setTuples(ArrayList<Hashtable<String, Object>> tuples) {
		Tuples = tuples;
	}


	public int getMax() {
		return max;
	}
	
	

	public  void printToFile() throws Exception {
		
		Formatter fl = new Formatter (this.Folder +  "/" +this.getFileName());
		FileOutputStream f =new  FileOutputStream(Folder +  "/" +this.getFileName());
		ObjectOutputStream out = new ObjectOutputStream(f);
		out.writeObject(this);
		out.close();
		f.close();
		
	}

	public String getFileName() {
		return FileName;
	}


	public void setFileName(String fileName) {
		FileName = fileName;
	}


	public Hashtable<String,String> getHtblColNameType() {
		return htblColNameType;
	}


	public void setHtblColNameType(Hashtable<String,String> htblColNameType) {
		this.htblColNameType = htblColNameType;
	}
	
	public static void main(String [] args) {

				
	}
}






