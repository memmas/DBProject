package team32;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;


public class Table {

	private String name;
	private Hashtable<String,String> htblColNameType;
	private ArrayList<Page> pages;
	private ArrayList<Hashtable<String,Object>> tuples;
	private String strCusteringKeyColumn;
	private static int PageCounter=1 ;
	
	
	 public void addToTuples(Hashtable<String, Object> NewTuple) {
		 
		 
		 
         Hashtable<String, Object> t = new Hashtable<String, Object>();
		 
		 ArrayList<String> keys = new ArrayList<>();
		    ArrayList<Object> values = new ArrayList<>();
		    Enumeration e = NewTuple.keys();
		    while(e.hasMoreElements()){
		    	String key = (String) e.nextElement();
		    	keys.add(key);
		    }
		    for(String key: keys){
		    	values.add(NewTuple.get(key));
		    }
		for(int i = 0; i < keys.size();i++)
			t.put(keys.get(i), values.get(i));
			 
		tuples.add(t);
		
		//sort method
			 
		 try {
			sort(tuples);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		 int counter = 0;
	
//		
		 for(int i = 0 ; i < pages.size();i++ ){
			 pages.get(i).getTuples().clear();
		 }
		int TupleCounter = 0 ;
		 for(int i = 0 ; i < pages.size();i++){
			 
			 for(int j = 0 ; j < pages.get(i).getMax() && TupleCounter< tuples.size();j++){
				 pages.get(i).getTuples().add(tuples.get(TupleCounter));
				 TupleCounter++;
			 }
			 try {
				pages.get(i).printToFile();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 if(i == pages.size()-1 && TupleCounter < tuples.size()-1){
				 pages.add(new Page(name, htblColNameType, name+PageCounter+".class", strCusteringKeyColumn));
				 PageCounter ++;
			 }
		 }
		
		}
	
	
	public static int getPageCounter() {
		return PageCounter;
	}

	public Table (String name,String strCusteringKeyColumn,Hashtable<String,String> htblColNameType ){
    	this.name = name;
    	this.htblColNameType = htblColNameType;
    	tuples = new ArrayList<Hashtable<String,Object>>();
    	this.strCusteringKeyColumn = strCusteringKeyColumn;
    	this.name = name;
    	pages = new ArrayList<Page>();
    	pages.add(new Page(name,htblColNameType,name+PageCounter+".ser",this.strCusteringKeyColumn));
    	PageCounter++;
    }
	
	public ArrayList<Hashtable<String, Object>> getTuples() {
		return tuples;
	}


	public void setTuples(ArrayList<Hashtable<String, Object>> tuples) {
		this.tuples = tuples;
	}


	public String getStrCusteringKeyColumn() {
		return strCusteringKeyColumn;
	}


	public void setStrCusteringKeyColumn(String strCusteringKeyColumn) {
		this.strCusteringKeyColumn = strCusteringKeyColumn;
	}


	public void sort(ArrayList< Hashtable<String, Object>> tuples) throws IOException{
		
		
		String colName = "";
	    String colType = "";
	    int type=0;
	
		
		   try {
			   colName = this.strCusteringKeyColumn;
			   colType = (String) htblColNameType.get(colName);
			   
		  System.out.println(colName + " " + colType);

		    	   if(colType.equals("java.lang.String")) type = 1;
		    	   
		    	  else
		       if( colType.equals("java.lang.Integer")){
		    	   type  = 2;
		       }
		    	   if( colType.equals("java.lang.Double")){
			    	   type  = 3;
			       }
		       if(type == 2){
		    	  
		    	   int size = tuples.size();
		    	   int sortedSize = 0;
		    	   for(int i = 1 ; i < size;i++){
			    	   

		    		   int j =i;
		    		   do{ 
		    			   if(((Integer)tuples.get(j).get("id")).intValue() < 
		   					    ((Integer)tuples.get(j-1).get("id")).intValue())
		    					   {
		    				  
		    				Hashtable<String,Object> small = tuples.get(j);
		    			    Hashtable<String,Object> large = tuples.get(j-1);
		    			    tuples.set(j-1, small);
		    			    tuples.set(j, large);
		    		   }
		    			   
		    		   j--;
		    		  
		    		   }while(j > sortedSize);
		    		   
		    	   }
		       }
		       
		       if(type == 3){
		    	 
		    	   int size = tuples.size();
		    	   int sortedSize = 0;
		    	   for(int i = 1 ; i < size;i++){
			    	  

		    		   int j =i;
		    		   do{
		    			   if(((Double)tuples.get(j).get("id")).doubleValue() < 
		   					    ((Double)tuples.get(j-1).get("id")).doubleValue())
		    					   {
		    				  
		    				Hashtable<String,Object> small = tuples.get(j);
		    			    Hashtable<String,Object> large = tuples.get(j-1);
		    			    tuples.set(j-1, small);
		    			    tuples.set(j, large);
		    		   }
		    			  
		    		   j--;
		    		  
		    		   }while(j > sortedSize);
		    		  		    	   }
		       }
		       
		       
		       
		       if(type == 1){
		    	   
		    	   int size = tuples.size();
		    	   int sortedSize = 0;
		    	   for(int i = 1 ; i < size;i++){
		    		   int j =i;
		    		   do{
		    			   if(( (String)tuples.get(j).get("id"))
		    					   .compareTo(( (String)tuples.get(j-1).get("id"))) < 0){
		    				Hashtable<String,Object> small = tuples.get(j);
		    			    Hashtable<String,Object> large = tuples.get(j-1);
		    			    tuples.set(j-1, small);
		    			    tuples.set(j, large);
		    		   }
		    		   j--;
		    		   }while(j > sortedSize);
		       }
		       }}
		      catch (Exception e) {
		          e.printStackTrace();
		       } 
		
	}
		        


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Hashtable<String, String> getHtblColNameType() {
		return htblColNameType;
	}

	public void setHtblColNameType(Hashtable<String, String> htblColNameType) {
		this.htblColNameType = htblColNameType;
	}

	public ArrayList<Page> getPages() {
		return pages;
	}

	public void setPages(ArrayList<Page> pages) {
		this.pages = pages;
	}
	
}
